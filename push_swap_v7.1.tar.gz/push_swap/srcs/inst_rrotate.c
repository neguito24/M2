/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   inst_rrotate.c                                     :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: anrivera <anrivera@student.42.fr>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2024/10/16 12:13:23 by anrivera          #+#    #+#             */
/*   Updated: 2025/01/21 10:31:06 by anrivera         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "../includes/push_swap.h"

void	rev_rotate_stack(t_stack **stack)
{
	t_stack	*last_node;

	if (stack == NULL || (*stack) == NULL || (*stack)->next == NULL)
		return ;
	last_node = ft_find_last_node(*stack);
	last_node->prev->next = NULL;
	last_node->next = *stack;
	last_node->prev = NULL;
	*stack = last_node;
	last_node->next->prev = last_node;
}

void	rra(t_stack **a)
{
	rev_rotate_stack(a);
	ft_printf("ra\n");
}

void	rrb(t_stack **b)
{
	rev_rotate_stack(b);
	ft_printf("rb\n");
}

void	rrr(t_stack **a, t_stack **b)
{
	rev_rotate_stack(a);
	rev_rotate_stack(b);
	ft_printf("rr\n");
}
