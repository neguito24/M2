/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_check_input.c                                   :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: anrivera <anrivera@student.42.fr>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2024/07/31 13:55:35 by anrivera          #+#    #+#             */
/*   Updated: 2025/01/21 10:22:03 by anrivera         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "../includes/push_swap.h"

//Check first if the elements are all numbers, symbols + or -

int	ft_check_valid_digit(char *str)
{
	int	i;

	i = 0;
	while (str[i] != '\0')
	{
		if (ft_isdigit(str[i]) || str[i] == '-' || str[i] == ' '
			|| str[i] == '+')
		{
			if ((str[i] == '-' || str[i] == '+' ) && !ft_isdigit(str[i + 1]))
				return (0);
		}
		else
			return (0);
		i++;
	}
	return (1);
}

void	ft_check_format_args(int argc, char *argv[])
{
	int		i;

	i = 1;
	while (i < argc)
	{
		if (!ft_check_valid_digit(argv[i]))
		{
			ft_error();
		}
		i++;
	}
}

int	*ft_check_constraints(char **arr, int index, int size, char mem)
{
	long	eval;
	int		*number;
	int		i;

	i = 0;
	number = (int *) malloc(sizeof(int) * size);
	if (number == NULL)
		exit(EXIT_FAILURE);
	while (arr[index])
	{
		eval = ft_atol(arr[index]);
		if (eval > INT_MAX || eval < INT_MIN)
		{
			free(number);
			if (mem == 'Y')
				free_mem_arr (arr);
			ft_error();
		}
		number[i++] = eval;
		index ++;
	}
	return (number);
}

int	ft_check_duplicates(int *nbr, int size)
{
	int	i;
	int	j;

	i = 0;
	j = 0;
	while (i < size)
	{
		j = i + 1;
		while (j < size)
		{
			if (nbr[i] == nbr[j])
				return (1);
			j++;
		}
		i++;
	}
	return (0);
}
