/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_sort_stack.c                                    :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: anrivera <anrivera@student.42.fr>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2025/01/08 11:31:19 by anrivera          #+#    #+#             */
/*   Updated: 2025/01/21 10:19:44 by anrivera         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "../includes/push_swap.h"

void	rotate_both(t_stack **a, t_stack **b, t_stack *cheapest)
{
	while (*b != cheapest->target && *a != cheapest)
		rr(a, b);
	set_index(*a);
	set_index(*b);
}

void	rev_rotate_both(t_stack **a, t_stack **b, t_stack *cheapest)
{
	while (*b != cheapest->target && *a != cheapest)
		rrr(a, b);
	set_index(*a);
	set_index(*b);
}

void	push_a_to_b(t_stack **a, t_stack **b)
{
	t_stack	*cheapest;

	cheapest = get_cheapest(*a);
	if (cheapest->above_median && cheapest->target->above_median)
		rotate_both(a, b, cheapest);
	else if (!cheapest->above_median && !cheapest->target->above_median)
		rev_rotate_both(a, b, cheapest);
	prep_for_push(a, cheapest, 'a');
	prep_for_push(b, cheapest->target, 'b');
	pb(b, a);
}

void	push_b_to_a(t_stack **a, t_stack **b)
{
	prep_for_push(a, (*b)->target, 'a');
	pa(a, b);
}

void	ft_sort_stack(t_stack **a, t_stack **b)
{
	int	size_a;

	size_a = ft_stack_lenght(*a);
	if (size_a-- > 3 && !ft_stack_sorted(*a))
		pb (b, a);
	if (size_a-- > 3 && !ft_stack_sorted(*a))
		pb (b, a);
	while (size_a-- > 3 && !ft_stack_sorted(*a))
	{
		init_a(*a, *b);
		push_a_to_b(a, b);
	}
	ft_sort_three(a);
	while (*b)
	{
		init_b(*a, *b);
		push_b_to_a(a, b);
	}
	set_index(*a);
	min_on_top(a);
}
