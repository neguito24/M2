/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   push_swap.h                                        :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: anrivera <anrivera@student.42.fr>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2024/07/29 12:38:45 by anrivera          #+#    #+#             */
/*   Updated: 2025/01/20 15:05:59 by anrivera         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#ifndef PUSH_SWAP_H
# define PUSH_SWAP_H

# include <stdio.h>
# include <unistd.h>
# include <limits.h>
# include <stdlib.h>
# include <stdbool.h>
# include "../ft_printf/libft/libft.h"
# include "../ft_printf/ft_printf.h"

typedef struct s_stack
{
	int				index;
	int				nbr;
	int				cost;
	int				above_median;
	int				cheapest;
	struct s_stack	*target;			
	struct s_stack	*next;
	struct s_stack	*prev;
}	t_stack;

int		ft_get_args( int argc, char *argv[]);
void	ft_error(void);
int		*ft_check_constraints(char **arr, int index, int size, char mem);
int		ft_check_valid_digit(char *str);
void	ft_check_format_args( int argc, char *argv[]);
int		ft_check_duplicates(int *nbr, int size);
void	free_mem_arr(char **arr);
long	ft_atol(const char *nptr);
int		ft_count_nbr(char **arr);
t_stack	*ft_init_stack(char **arr, int index, int size, char mem);
t_stack	*ft_find_last_node(t_stack *list);
void	ft_append_node(t_stack **stack, int n);
void	ft_free_stack(t_stack **stack);
void	swap_stack(t_stack **stack);
void	sa(t_stack **a);
void	sb(t_stack **b);
void	rotate_stack(t_stack **stack);
void	ra(t_stack **a);
void	rb(t_stack **b);
void	rr(t_stack **a, t_stack **b);
void	rev_rotate_stack(t_stack **stack);
void	rra(t_stack **a);
void	rrb(t_stack **b);
void	rrr(t_stack **a, t_stack **b);
void	push(t_stack **dst, t_stack **src);
void	pa(t_stack **a, t_stack **b);
void	pb(t_stack **b, t_stack **a);
int		ft_stack_sorted(t_stack *stack);
int		ft_stack_lenght(t_stack *stack);
t_stack	*ft_find_max(t_stack *stack);
void	ft_sort_three(t_stack **a);
void	ft_sort_stack(t_stack **a, t_stack **b);
void	set_index(t_stack *stack);
void	set_target_a(t_stack *a, t_stack *b);
void	set_cost_a(t_stack *a, t_stack *b);
void	set_cheapest(t_stack *stack);
void	init_a(t_stack *a, t_stack *b);

#endif