/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_sort_stack.c                                    :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: anrivera <anrivera@student.42.fr>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2025/01/20 11:31:19 by anrivera          #+#    #+#             */
/*   Updated: 2025/01/20 15:00:04 by anrivera         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "../includes/push_swap.h"
void	push_a_to_b(t_stack *a, t_stack *b)
{
	t_stack	*cheapeast;
	cheapeast = get_chea
}
void	ft_sort_stack(t_stack **a, t_stack **b)
{
	int	size_a;

	size_a = ft_stack_lenght(*a);
	if (size_a-- > 3 && !stack_sorted(*a))
		pb (b, a);
	if (size_a-- > 3 && !stack_sorted(*a))
		pb (b, a);
	while (size_a-- > 3 && !stack_sorted(*a))
	{
		ft_init_a(*a, *b);
		push_a_to_b(a,b);
	}


	}