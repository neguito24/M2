/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   flood_fill.c                                       :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: fdaher <fdaher@student.42.fr>              +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2024/08/30 13:15:14 by fdaher            #+#    #+#             */
/*   Updated: 2024/08/31 12:45:56 by fdaher           ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "so_long.h"

char	**copy_map(char **str)
{
	char	**copy;
	int		i;
	int		j;

	i = 0;
	j = 0;
	while (str[i])
		i++;
	copy = (char **)malloc(sizeof(char *) * (i + 1));
	i = 0;
	while (str[i])
	{
		copy[j] = ft_strdup(str[i]);
		j++;
		i++;
	}
	copy[j] = NULL;
	return (copy);
}

int	flood_reachable_collectible(char **tab, t_point size, t_point cur)
{
	int	count;

	count = 0;
	if (cur.x < 0 || cur.y < 0 || cur.x >= size.x || cur.y >= size.y
		|| (tab[cur.y][cur.x] != 'P' && tab[cur.y][cur.x] != '0'
		&& tab[cur.y][cur.x] != 'C'))
		return (count);
	if (tab[cur.y][cur.x] == 'C')
		count++;
	tab[cur.y][cur.x] = '1';
	count += flood_reachable_collectible(tab, size,
			(t_point){cur.x - 1, cur.y});
	count += flood_reachable_collectible(tab, size,
			(t_point){cur.x + 1, cur.y});
	count += flood_reachable_collectible(tab, size,
			(t_point){cur.x, cur.y - 1});
	count += flood_reachable_collectible(tab, size,
			(t_point){cur.x, cur.y + 1});
	return (count);
}

int	reachable_collectible(char **str)
{
	char	**copy;
	t_point	size;
	t_point	cur;
	int		count;

	if (!str)
		return (0);
	get_size_map(str, &size);
	get_position(str, &cur, 'P');
	copy = copy_map(str);
	count = flood_reachable_collectible(copy, size, cur);
	free_array(copy);
	if (count == nb_collectible(str))
		return (1);
	return (0);
}

int	flood_reachable_exit(char **tab, t_point size, t_point cur)
{
	if (cur.x < 0 || cur.y < 0 || cur.x >= size.x || cur.y >= size.y
		|| (tab[cur.y][cur.x] != 'P' && tab[cur.y][cur.x] != 'C' &&
			tab[cur.y][cur.x] != 'E' && tab[cur.y][cur.x] != '0'))
		return (0);
	if (tab[cur.y][cur.x] == 'E')
		return (1);
	tab[cur.y][cur.x] = '1';
	if (flood_reachable_exit(tab, size, (t_point){cur.x - 1, cur.y}) ||
		flood_reachable_exit(tab, size, (t_point){cur.x + 1, cur.y}) ||
		flood_reachable_exit(tab, size, (t_point){cur.x, cur.y - 1}) ||
		flood_reachable_exit(tab, size, (t_point){cur.x, cur.y + 1}))
		return (1);
	return (0);
}

int	reachable_exit(char **str)
{
	char	**copy;
	t_point	size;
	t_point	cur;
	int		i;

	get_size_map(str, &size);
	get_position(str, &cur, 'P');
	copy = copy_map(str);
	i = flood_reachable_exit(copy, size, cur);
	free_array(copy);
	if (i == 1)
		return (1);
	return (0);
}

// int	main(int argc, char **argv)
// {
// 	char **str;
// 	(void)argc;
// 	str = read_from_file(argv[1]);
// 	printf("%d", reachable_collectible(str));
// 	// printf("%d", reachable_exit(str));
// 	free_array(str);
// }

// int main(int argc, char **argv)
// {
// 	char **str;
// 	char **copy;
// 	t_point size;
// 	t_point pos;
// 	int i = 0;
// 	int count;
// 	(void)argc;
// 	str = read_from_file(argv[1]);
// 	copy = copy_map(str);
// 	get_size_map(str, &size);
// 	get_position(str, &pos, 'P');
// 	// count = flood_reachable_collectible(copy, size, pos);
// 	count = flood_reachable_exit(copy, size, pos);
// 	printf("%d", count);
// 	while(copy[i])
// 	{
// 		printf("line->%d : %s", i, copy[i]);
// 		i++;
// 	}
// 	free_array(copy);
// 	free_array(str);
// }

// int main(int argc, char **argv)
// {
// 	char **str;
// 	char **copy;
// 	int i = 0;
// 	(void)argc;
// 	str = read_from_file(argv[1]);
// 	copy = copy_map(str);
// 	while (copy[i])
// 	{
// 		printf("line->%d  :%s", i, copy[i]);
// 		i++;
// 	}
// 	free_array(copy);
// 	free_array(str);
// 	return(0);
// }