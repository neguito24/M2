/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   check.c                                            :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: fdaher <fdaher@student.42.fr>              +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2024/08/30 12:00:18 by fdaher            #+#    #+#             */
/*   Updated: 2024/08/30 13:16:21 by fdaher           ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "so_long.h"

int	nb_collectible(char **str)
{
	int	count;
	int	i;
	int	j;

	i = 0;
	count = 0;
	while (str[i])
	{
		j = 0;
		while (str[i][j])
		{
			if (str[i][j] == 'C')
				count++;
			j++;
		}
		i++;
	}
	return (count);
}

int	check_one_p_e(char **str, char a)
{
	int	count;
	int	i;
	int	j;

	count = 0;
	i = 0;
	while (str[i])
	{
		j = 0;
		while (str[i][j])
		{
			if (str[i][j] == a)
				count++;
			j++;
		}
		i++;
	}
	if (count == 1)
		return (1);
	return (0);
}

int	check_border(char **str)
{
	int	i;
	int	j;

	i = 1;
	j = 0;
	while (str[0][j])
	{
		if (str[0][j] != '1')
			return (0);
		j++;
	}
	while (str[i] && str[i + 1])
	{
		if (str[i][0] != '1' || str[i][ft_strlen(str[i]) - 1] != '1')
			return (0);
		i++;
	}
	j = 0;
	while (str[i][j])
	{
		if (str[i][j] != '1')
			return (0);
		j++;
	}
	return (1);
}

int	check_rectangle(char **str)
{
	int	i;

	i = 0;
	while (str[i] && str[i + 1])
	{
		if (ft_strlen(str[i]) != ft_strlen(str[i + 1]))
			return (0);
		i++;
	}
	return (1);
}

int	check_acceptchar(char **str)
{
	int		i;
	int		j;
	char	a;

	i = 0;
	while (str[i])
	{
		j = 0;
		while (str[i][j])
		{
			a = str[i][j];
			if (a != '1' && a != '0' && a != 'P' && a != 'E' && a != 'C')
				return (0);
			j++;
		}
		i++;
	}
	return (1);
}

// int main(int argc, char **argv)
// {
// 	char **str;

// 	(void)argc;
// 	str = read_from_file(argv[1]);
// 	// printf("%d", nb_collectible(str));
// 	// printf("%d", check_one_p_e(str, 'E'));
// 	// printf("%d", check_border(str));
// 	// printf("%d", check_rectangle(str));
// 	printf("%d", check_acceptchar(str));
// 	free_array(str);
// }