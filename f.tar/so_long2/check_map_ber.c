/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   check_map_ber.c                                    :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: fdaher <fdaher@student.42.fr>              +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2024/08/31 11:12:06 by fdaher            #+#    #+#             */
/*   Updated: 2024/09/09 13:36:12 by fdaher           ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "so_long.h"

int	check_ber(char *str)
{
	char	*extension;

	extension = ft_strrchr(str, '.');
	if (!extension)
		return (0);
	if (ft_strncmp(extension, ".ber", 4) == 0)
		return (1);
	return (0);
}

void	put_error(char *s, char **str)
{
	ft_putstr_fd(s, 2);
	if (str)
		free_array(str);
	exit(1);
}

void	check_map(char **str)
{
	if (!str)
		exit(1);
	if (check_acceptchar(str) == 0)
		put_error("Error\nForbidden character\n", str);
	else if (nb_collectible(str) < 1)
		put_error("Error\nDoes not contain collectibles\n", str);
	else if (check_one_p_e(str, 'P') == 0)
		put_error("Error\nThe number of Players must be one\n", str);
	else if (check_one_p_e(str, 'E') == 0)
		put_error("Error\nwe must have one Exit\n", str);
	else if (check_rectangle(str) == 0)
		put_error("Error\nIt's not a rectangle\n", str);
	else if (check_border(str) == 0)
		put_error("Error\nIt's not closed by wall\n", str);
	else if (reachable_collectible(str) == 0)
		put_error("Error\nNot all collectible are accessible\n", str);
	else if (reachable_exit(str) == 0)
		put_error("Error\nThe exit is not accessible\n", str);
}

// int main(int argc, char **argv)
// {
// 	char **str;
// 	(void) argc;
// 	str = read_from_file(argv[1]);
// 	check_map(str);
// 	free_array(str);
// }

// int main()
// {
//     char s[] = "fatimaber";
// 	char *str;
// 	str = ft_strrchr(s, '.');
//     printf("->%s\n", str);
// 	printf("%d", check_ber(s));
// }

// int main(int argc, char **argv)
// {
// 	char **str = read_from_file(argv[1]);
// 	(void) argc;
// 	put_error("Error\ncharactere\n", str);
// }