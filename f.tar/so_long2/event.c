/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   event.c                                            :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: fdaher <fdaher@student.42.fr>              +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2024/09/06 11:25:59 by fdaher            #+#    #+#             */
/*   Updated: 2024/09/09 13:15:41 by fdaher           ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "so_long.h"

int	close_window(t_game *game)
{
	if (game->map)
		free_array(game->map);
	free_game(game->mlx, game->win, game->img, 2);
	free(game);
	exit(0);
	return (0);
}

void	check_position(t_point *play, t_point *new, t_game *g)
{
	if (new->x >= 0 && g->map[new->y][new->x] != '1'
			&& new->y >= 0 && g->map[new->y][new->x] != 'E')
	{
		if (g->map[new->y][new->x] == 'C')
			(g->nb_c)--;
		g->map[play->y][play->x] = '0';
		g->map[new->y][new->x] = 'P';
		put_image(g);
	}
	if (g->map[new->y][new->x] == 'E')
	{
		if (g->nb_c == 0)
		{
			ft_putstr_fd("Congratulations! You won!\n", 1);
			close_window(g);
		}
	}
}

void	write_move(t_game *game)
{
	game->moves++;
	ft_putstr_fd("Moves : ", 1);
	ft_putnbr_fd(game->moves, 1);
	ft_putchar_fd('\n', 1);
}

int	key_press(int keycode, t_game *game)
{
	t_point	play;
	t_point	new;

	get_position(game->map, &play, 'P');
	new.x = play.x;
	new.y = play.y;
	if (keycode == 65307)
		close_window(game);
	else if (keycode == 119 || keycode == 65362)
		(new.y)--;
	else if (keycode == 115 || keycode == 65364)
		(new.y)++;
	else if (keycode == 97 || keycode == 65361)
		(new.x)--;
	else if (keycode == 100 || keycode == 65363)
		(new.x)++;
	check_position(&play, &new, game);
	if (game->map[new.y][new.x] != '1' && game->map[new.y][new.x] != 'E'
		&& (keycode == 65307 || keycode == 119 || keycode == 115
		|| keycode == 97 || keycode == 100 || keycode == 65362
		|| keycode == 65364 || keycode == 65361 || keycode == 65363))
		write_move(game);
	return (0);
}

// int main(int argc, char **argv)
// {
// 	t_game *g;
// 	(void)argc;
// 	g = malloc(sizeof(t_game));
// 	char **str = read_from_file(argv[1]);
// 	init_struct(g, str);
// 	mlx_hook(g->win, 17, 0, close_window, g);
// 	mlx_key_hook(g->win, key_press, g);
// 	mlx_loop(g->mlx);
// 	free_game(g->mlx, g->win, g->img, 2);
// 	free_array(g->map);
// 	free(g);
// 	return (0);
// }