/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   read_from_file.c                                   :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: fdaher <fdaher@student.42.fr>              +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2024/08/30 10:35:44 by fdaher            #+#    #+#             */
/*   Updated: 2024/09/09 12:40:19 by fdaher           ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "so_long.h"

char	**ft_check_flag(int flag, char *res, int fd)
{
	char	**str;

	close (fd);
	if (flag)
		return (ft_putstr_fd("Error\nEmty line\n", 2), free(res), NULL);
	str = ft_split(res, '\n');
	return (free(res), str);
}

char	**read_from_file(const char *s)
{
	char	*res;
	char	*temp;
	char	*line;
	int		fd;
	int		flag;

	flag = 0;
	res = NULL;
	fd = open(s, O_RDONLY);
	if (fd == -1)
		return (close(fd), ft_putstr_fd("Error\nFailed to open file\n", 2), NULL);
	line = get_next_line(fd);
	while (line)
	{
		if (line[0] == '\n')
			flag = 1;
		temp = ft_strjoin(res, line);
		free_two(res, line);
		res = temp;
		line = get_next_line(fd);
	}
	return (ft_check_flag(flag, res, fd));
}

void	get_size_map(char **str, t_point *size)
{
	int	i;

	i = 0;
	if (!str)
		return ;
	while (str[i])
		i++;
	if (str[0])
		size->x = ft_strlen(str[0]);
	size->y = i;
}

void	get_position(char **str, t_point *position, char a)
{
	int	i;
	int	j;

	i = 0;
	while (str[i])
	{
		j = 0;
		while (str[i][j])
		{
			if (str[i][j] == a)
			{
				position->x = j;
				position->y = i;
			}
			j++;
		}
		i++;
	}
}

// int main(int argc, char **argv)
// {
// 	char **str;
// 	int i = 0;
// 	(void) argc;
// 	str = read_from_file(argv[1]);
// 	if (!str)
// 		return (1);
// 	while (str && str[i])
// 	{
// 		printf("line->%d : %s", i, str[i]);
// 		i++;
// 	}
// 	free_array(str);
// 	return (0);
// }

// int	main(int argc, char **argv)
// {
// 	char **res;
// 	// int i = 0;
// 	t_point	position;
// 	(void)argc;
// 	res = read_from_file(argv[1]);
// 	// while (res[i])
// 	// {
// 	// 	printf("line ->%d  :%s", i, res[i]);
// 	// 	i++;
// 	// }
// 	// size.x = 0;
// 	// size.y = 0;
// 	get_position(res, &position, 'E');
// 	printf("x=%d  y=%d ", position.x, position.y);
// 	free_array(res);
// }

// int	main(int argc, char **argv)
// {
// 	char **res;
// 	int i = 0;
// 	t_point	size;
// 	(void)argc;
// 	res = read_from_file(argv[1]);
// 	while (res[i])
// 	{
// 		printf("line ->%d  :%s", i, res[i]);
// 		i++;
// 	}
// 	size.x = 0;
// 	size.y = 0;
// 	get_size_map(res, &size);
// 	printf("\nx=%d  y=%d ", size.x, size.y);
// 	free_array(res);
// }