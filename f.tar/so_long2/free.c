/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   free.c                                             :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: fdaher <fdaher@student.42.fr>              +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2024/08/30 10:40:49 by fdaher            #+#    #+#             */
/*   Updated: 2024/09/09 13:16:40 by fdaher           ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "so_long.h"

void	free_two(char *s1, char *s2)
{
	if (s1)
		free(s1);
	if (s2)
		free(s2);
}

void	free_array(char **str)
{
	int	i;

	i = 0;
	while (str[i])
	{
		free(str[i]);
		i++;
	}
	free(str);
	str = NULL;
}

void	free_game(void *mlx, void *win, void **img, int i)
{
	int	j;

	j = 0;
	if (img && i >= 2)
	{
		while (j < 6)
		{
			if (img[j])
				mlx_destroy_image(mlx, img[j]);
			j++;
		}
	}
	if (win && i >= 1)
		mlx_destroy_window(mlx, win);
	mlx_destroy_display(mlx);
	free(mlx);
}

// int main()
// {
// 	void *mlx;
// 	void *win;
// 	// int i;
// 	// i = 0;
// 	mlx = mlx_init();
// 	if (!mlx)
// 		return(1);
// 	win = mlx_new_window(mlx, 500, 500, "so_long");
// 		if (!win)
// 			{
// 				free_game(mlx,NULL, NULL, 0);
// 				return (1);
// 			}
// 	// mlx_loop(mlx);
// 	free_game(mlx, win, NULL, 1);
// 	return(0);
// }