/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   so_long.h                                          :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: fdaher <fdaher@student.42.fr>              +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2024/08/29 18:18:24 by fdaher            #+#    #+#             */
/*   Updated: 2024/09/06 14:48:13 by fdaher           ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#ifndef SO_LONG_H
# define SO_LONG_H
# include <unistd.h>
# include <fcntl.h>
# include <stdlib.h>
# include <stdio.h>
# include "get_next_line.h"
# include "./libft/libft.h"
# include "./minilibx-linux/mlx.h"
# include "minilibx-linux/mlx_int.h"

# ifndef PIXELS
#  define PIXELS 50
# endif

typedef struct s_point
{
	int	x;
	int	y;
}	t_point;

typedef struct s_game
{
	char	**map;
	void	*mlx;
	void	*win;
	void	*img[6];
	int		nb_c;
	int		moves;
}	t_game;

void	free_two(char *s1, char *s2);
void	free_array(char **str);
void	free_game(void *mlx, void *win, void **img, int i);

char	**read_from_file(const char *s);
void	get_size_map(char **str, t_point *size);
void	get_position(char **str, t_point *position, char a);

int		nb_collectible(char **str);
int		check_one_p_e(char **str, char a);
int		check_border(char **str);
int		check_rectangle(char **str);
int		check_acceptchar(char **str);

char	**copy_map(char **str);
int		flood_reachable_collectible(char **tab, t_point size, t_point cur);
int		reachable_collectible(char **str);
int		flood_reachable_exit(char **tab, t_point size, t_point cur);
int		reachable_exit(char **str);

int		check_ber(char *str);
void	put_error(char *s, char **str);
void	check_map(char **str);

void	*create_window(void *mlx, t_point size, char **str, char *title);
void	init_struct(t_game *game, char **str);

void	*load_image(t_game *game, char *filename);
void	get_image(t_game *game);
void	replace_char(t_game *g, int j, int i);
void	put_image(t_game *g);

int		close_window(t_game *game);
void	check_position(t_point *play, t_point *new, t_game *g);
void	write_move(t_game *game);
int		key_press(int keycode, t_game *game);

#endif