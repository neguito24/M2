/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   put_image.c                                        :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: fdaher <fdaher@student.42.fr>              +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2024/09/03 14:04:05 by fdaher            #+#    #+#             */
/*   Updated: 2024/09/06 14:19:26 by fdaher           ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "so_long.h"

void	*load_image(t_game *game, char *filename)
{
	void	*img;
	int		pixels;

	pixels = PIXELS;
	img = mlx_xpm_file_to_image(game->mlx, filename, &pixels, &pixels);
	if (!img)
	{
		ft_putstr_fd("Error\nFailed load image\n", 2);
		free_array(game->map);
		free_game(game->mlx, game->win, game->img, 2);
		if (game)
			free(game);
		exit(1);
	}
	return (img);
}

void	get_image(t_game *game)
{
	if (!game)
		return ;
	game->img[0] = load_image(game, "./images/emty.xpm");
	game->img[1] = load_image(game, "./images/wall.xpm");
	game->img[2] = load_image(game, "./images/player.xpm");
	game->img[3] = load_image(game, "./images/collectible.xpm");
	game->img[4] = load_image(game, "./images/exit.xpm");
	game->img[5] = load_image(game, "./images/exit_o.xpm");
}

void	replace_char(t_game *g, int j, int i)
{
	if (g->map)
	{
		if ((g->map)[i][j] == '0')
			mlx_put_image_to_window(g->mlx, g->win, (g->img)[0],
				j * PIXELS, i * PIXELS);
		if ((g->map)[i][j] == '1')
			mlx_put_image_to_window(g->mlx, g->win, (g->img)[1],
				j * PIXELS, i * PIXELS);
		if ((g->map)[i][j] == 'P')
			mlx_put_image_to_window(g->mlx, g->win, (g->img)[2],
				j * PIXELS, i * PIXELS);
		if ((g->map)[i][j] == 'C')
			mlx_put_image_to_window(g->mlx, g->win, (g->img)[3],
				j * PIXELS, i * PIXELS);
		if ((g->map)[i][j] == 'E')
		{
			if (g->nb_c == 0)
				mlx_put_image_to_window(g->mlx, g->win, (g->img)[5],
					j * PIXELS, i * PIXELS);
			else
				mlx_put_image_to_window(g->mlx, g->win, (g->img)[4],
					j * PIXELS, i * PIXELS);
		}
	}
}

void	put_image(t_game *g)
{
	int	i;
	int	j;

	if (!g)
		return ;
	i = 0;
	while ((g->map)[i])
	{
		j = 0;
		while ((g->map)[i][j])
		{
			replace_char(g, j, i);
			j++;
		}
		i++;
	}
}

// int main()
// {
//     t_game  game;
//     t_point size;
//     char *str[]= {"11111", "1PC01", "1CE01", "11111", NULL};

//     get_size_map(str, &size);
//     game.mlx = mlx_init();
//     if (!game.mlx)
//         return (1);
//     game.win = create_window(game.mlx, size.x, size.y, "fatima");
//     get_image(&game);
//     game.map = str;
//     put_image(&game);
//     mlx_loop(game.mlx);
//     free_game(game.mlx, game.win, game.img, 2);
// }