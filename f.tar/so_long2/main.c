/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   main.c                                             :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: fdaher <fdaher@student.42.fr>              +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2024/09/06 14:58:20 by fdaher            #+#    #+#             */
/*   Updated: 2024/09/09 13:36:26 by fdaher           ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "so_long.h"

int	main(int argc, char *argv[])
{
	t_game	*game;
	char	**str;

	if (argc != 2 || argv[1][0] == '\0' || check_ber(argv[1]) == 0)
		return (1);
	str = read_from_file(argv[1]);
	check_map(str);
	game = (t_game *)malloc(sizeof(t_game));
	if (!game)
		put_error("Error\nIn the malloc", str);
	init_struct(game, str);
	mlx_hook(game->win, 17, 0, close_window, game);
	mlx_key_hook(game->win, key_press, game);
	mlx_loop(game->mlx);
	free_array(game->map);
	free_game(game->mlx, game->win, game->img, 2);
	free (game);
	return (0);
}
