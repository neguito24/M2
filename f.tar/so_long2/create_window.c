/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   create_window.c                                    :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: fdaher <fdaher@student.42.fr>              +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2024/09/03 13:28:46 by fdaher            #+#    #+#             */
/*   Updated: 2024/09/09 13:14:36 by fdaher           ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "so_long.h"

void	*create_window(void *mlx, t_point size, char **str, char *title)
{
	void	*window;

	if (!mlx)
		return (NULL);
	window = mlx_new_window(mlx, (size.x) * PIXELS, (size.y) * PIXELS, title);
	if (!window)
	{
		free_game(mlx, NULL, NULL, 0);
		free_array(str);
		return (NULL);
	}
	return (window);
}

void	init_struct(t_game *game, char **str)
{
	t_point	size;

	ft_memset(game, 0, sizeof(t_game));
	game->mlx = mlx_init();
	if (!game->mlx)
	{
		free_array(str);
		free(game);
		exit(1);
	}
	get_size_map(str, &size);
	game->map = str;
	game->win = create_window(game->mlx, size, game->map, "so_long");
	if (!game->win)
	{
		free(game);
		exit(1);
	}
	game->nb_c = nb_collectible(game->map);
	game->moves = 0;
	get_image(game);
	put_image(game);
}

// int	main(int argc, char **argv)
// {
// 	t_game	*g;
// 	char **str;

// 	(void) argc;
// 	str = read_from_file(argv[1]);
// 	g = (t_game *)malloc(sizeof(t_game));
// 	init_struct(g, str);
// 	// mlx_loop(g->mlx);
// 	free_array(g->map);
// 	free_game(g->mlx, g->win, g->img, 2);
// 	free (g);
// }
// int main()
// {
// 	void *mlx;
// 	void *win;
// 
// 	mlx = mlx_init();
// 	if (!mlx)
// 		return(1);
// 	win = create_window(mlx, 10, 5, "fatima");
// 	// mlx_loop(mlx);
// 	free_game(mlx, win, NULL, 1);
// 	return (0);
// }