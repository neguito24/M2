/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   so_long.h                                          :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: anrivera <anrivera@student.42.fr>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2025/01/23 23:57:51 by anrivera          #+#    #+#             */
/*   Updated: 2025/01/31 15:14:15 by anrivera         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#ifndef SO_LONG_H
# define SO_LONG_H
# include "../ft_printf/libft/libft.h"
# include "../ft_printf/libft/get_next_line.h"
# include "../ft_printf/ft_printf.h"
# include "../minilibx-linux/mlx.h"
# include <unistd.h>
# include <stdlib.h>
# include <errno.h>
# include <stdlib.h>
# include <stdio.h>
# include <fcntl.h>

typedef struct s_player
{
	int	y;
	int	x;

}	t_player;

typedef struct s_img
{
	void	*empty;
	void	*collectible;
	void	*wall;
	void	*exit;
	void	*player;
}	t_img;

typedef struct s_map
{
	int				fd;
	char			*line;
	char			*file;
	char			**fild;
	char			**copy;
	char			*content;
	int				y;
	int				x;
	int				e;
	int				c;
	int				c_check;
	int				e_check;
	int				p;
	int				exit;
	int				moves;
	void			*mlx;
	void			*wnd;
	t_img			img;
	t_player		player;
}	t_map;

void	init_map(t_map *map, char **argv);
void	check_map(t_map *map);
void	check_file_format(t_map *map);
void	get_map_into_array(t_map *map);
void	check_map_size(t_map *map);
void	check_map_limits(t_map *map);
void	check_map_objects(t_map *map);
char	*safe_strjoin(char *s1, char *s2);
int		ft_open_file(t_map *map);
void	create_map_array(t_map *map);
void	error_file_ext(void);
void	error_open_file(t_map *map);
void	error_map_format_empty(t_map *map, int fd);
void	error_map_size(t_map *map);
void	error_map_limits(t_map *map);
void	error_map_objects(t_map *map);
void	free_exit_error(t_map *map);
void	free_map_array( char **fild);
void	free_failed_file_open(t_map *map);

#endif