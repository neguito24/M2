/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   error_handler.c                                    :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: anrivera <anrivera@student.42.fr>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2025/01/28 14:23:31 by anrivera          #+#    #+#             */
/*   Updated: 2025/01/31 15:15:48 by anrivera         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "../includes/so_long.h"

void	error_file_ext(void)
{
	ft_printf("ERROR: \n Expected BER file extension. \n");
	exit(EXIT_FAILURE);
}

void	error_open_file(t_map *map)
{
	ft_printf("ERROR: \n Failed to open file. \n");
	free_failed_file_open(map);
	exit(EXIT_FAILURE);
}

void	error_map_format_empty(t_map *map, int fd)
{
	ft_printf("ERROR: \n File is empty or not properly formated. \n");
	close(fd);
	free_exit_error(map);
}

void	error_map_size(t_map *map)
{
	ft_printf("ERROR: \n Map is not rectangular. \n");
	free_map_array(map->fild);
	free_map_array(map->copy);
	exit(EXIT_FAILURE);
}

void	error_map_limits(t_map *map)
{
	ft_printf("ERROR: \n Map is not limited. \n");
	free_map_array(map->fild);
	free_map_array(map->copy);
	exit(EXIT_FAILURE);
}
void	error_map_objects(t_map *map)
{
	ft_printf("ERROR: Map elements are incorrect. \n");
	free_map_array(map->fild);
	free_map_array(map->copy);
	exit(EXIT_FAILURE);
}
