/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   clean_memory.c                                     :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: anrivera <anrivera@student.42.fr>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2025/01/29 19:01:11 by anrivera          #+#    #+#             */
/*   Updated: 2025/01/31 15:14:00 by anrivera         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "../includes/so_long.h"

void	free_exit_error(t_map *map)
{
	if (map->fild)
		free_map_array(map->fild);
	if (map->copy)
		free_map_array(map->copy);
	if (map->content)
		free(map->content);
	if (map->line)
		free(map->line);
	exit(EXIT_FAILURE);
}

void	free_map_array( char **fild)
{
	int	i;

	i = 0;
	while (fild[i])
	{
		free(fild[i]);
		i++;
	}
	free(fild);
}

void	free_failed_file_open(t_map *map)
{
	if (map->content)
		free(map->content);
}
