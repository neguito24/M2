/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   map_format.c                                       :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: anrivera <anrivera@student.42.fr>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2025/01/28 14:20:28 by anrivera          #+#    #+#             */
/*   Updated: 2025/01/31 11:36:33 by anrivera         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "../includes/so_long.h"

void	check_file_format(t_map *map)
{
	size_t	len;

	len = ft_strlen(map->file);
	if (map->file[len - 1] != 'r' || map->file[len - 2] != 'e'
		|| map->file[len - 3] != 'b' || map->file[len - 4] != '.')
		error_file_ext();
	if (!ft_strnstr(map->file, ".ber", ft_strlen(map->file)))
		error_file_ext();
}

void	get_map_into_array(t_map *map)
{
	int		fd;

	map->y = 0;
	map->line = NULL;
	map->content = ft_strdup("");
	fd = ft_open_file(map->file);
	while (map->line)
	{
		map->line = get_next_line(fd);
		if (map->line[0] == '\0' || (map->line[0] == '\n'))
			free_exit_error(map);
		if (map->line == NULL)
			break ;
		map->content = safe_strjoin(map->content, map->line);
		free(map->line);
		if (!map->content)
			free_exit_error(map);
		map->y++;
	}
	close (fd);
	map->fild = ft_split(map->content, '\n');
	map->copy = ft_split(map->content, '\n');
	if (!map->fild || !map->copy)
		free_exit_error(map);
	free(map->content);
}

void	check_map_size(t_map *map)
{
	int	y;
	int	x;
	int	max_col_size;

	y = 0;
	x = 0;
	max_col_size = ft_strlen(map->fild[y]);
	while (y < map->y)
	{
		x = ft_strlen(map->fild[y]);
		if (max_col_size != x)
			error_map_size(map);
		y++;
	}
	map->x = max_col_size;
}

void	check_map_limits(t_map *map)
{
	int	x;
	int	y;

	ft_printf ("y = %d and x = %d \n", map->y, map->x);
	x = 0;
	while (map->fild[0][x] != '\0')
	{
		if (map->fild[0][x] != '1' || map->fild[map->y - 1][x] != '1')
			error_map_limits(map);
		x++;
	}
	y = 1;
	while (y < map->y)
	{
		if (map->fild[y][0] != '1' || map->fild[y][map->x - 1] != '1')
			error_map_limits(map);
		y++;
	}
}
