/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   main.c                                             :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: anrivera <anrivera@student.42.fr>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2025/01/23 15:49:55 by anrivera          #+#    #+#             */
/*   Updated: 2025/01/29 23:31:29 by anrivera         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

//Compile : cc  main.c -Lminilibx-linux -lmlx_Linux  -lmlx -lXext -lX11

#include "../includes/so_long.h"

int	main(int argc, char *argv[])
{
	t_map	map;
	int		i = 0;

	if (argc == 2)
	{
		init_map(&map, argv);
		check_map(&map);
		while (map.fild[i])
			printf("%s \n", map.fild[i++]);
		free_map_array(map.fild);
		free_map_array(map.copy);
	}
	
}
