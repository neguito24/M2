/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   main.c                                             :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: fdaher <fdaher@student.42.fr>              +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2024/09/05 14:31:40 by fdaher            #+#    #+#             */
/*   Updated: 2024/09/13 14:38:11 by fdaher           ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "pipex.h"

void	put_error(char *str)
{
	ft_putstr_fd(str, 2);
	exit (1);
}

void	check_fork(pid_t pid)
{
	if (pid < 0)
		put_error("Error in fork1\n");
}

int	main(int argc, char *argv[], char **envp)
{
	pid_t	pid1;
	pid_t	pid2;
	int		fd[2];

	if (argc == 5)
	{
		if (pipe(fd))
			put_error("Error in pipe\n");
		pid1 = fork();
		check_fork(pid1);
		if (pid1 == 0)
			process1(fd, argv, envp);
		pid2 = fork();
		check_fork(pid2);
		if (pid2 == 0)
			process2(fd, argv, envp);
		close(fd[0]);
		close (fd[1]);
		waitpid(pid1, NULL, 0);
		waitpid(pid2, NULL, 0);
	}
	else
		put_error("Error in number of argument\n");
	return (0);
}
