/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   pipex.h                                            :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: fdaher <fdaher@student.42.fr>              +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2024/09/05 14:25:05 by fdaher            #+#    #+#             */
/*   Updated: 2024/09/13 14:37:49 by fdaher           ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#ifndef PIPEX_H
# define PIPEX_H
# include <unistd.h>
# include <fcntl.h>
# include <stdlib.h>
# include <stdio.h>
# include <sys/wait.h>
# include <sys/types.h>
# include "./libft/libft.h"

void	put_error(char *str);
void	check_fork(pid_t pid);

void	process1(int fd[2], char **argv, char **envp);
void	process2(int fd[2], char **argv, char **envp);

void	free_array(char **str);
char	*find_path(char *cmd, char **envp);
void	execute(char *argv, char **envp);

#endif