/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   execute.c                                          :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: fdaher <fdaher@student.42.fr>              +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2024/09/11 13:04:30 by fdaher            #+#    #+#             */
/*   Updated: 2024/09/12 14:13:43 by fdaher           ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "pipex.h"

void	free_array(char **str)
{
	int	i;

	i = 0;
	while (str[i])
	{
		free (str[i]);
		i++;
	}
	free (str);
}

char	*find_path(char *cmd, char **envp)
{
	char	*path;
	char	**split_path;
	char	*part_path;
	int		i;

	i = 0;
	while (ft_strnstr (envp[i], "PATH", 4) == 0)
		i++;
	split_path = ft_split(envp[i] + 5, ':');
	i = 0;
	while (split_path[i])
	{
		part_path = ft_strjoin(split_path[i], "/");
		path = ft_strjoin(part_path, cmd);
		free(part_path);
		if (access(path, F_OK) == 0)
		{
			free_array(split_path);
			return (path);
		}
		free(path);
		i++;
	}
	free_array(split_path);
	return (0);
}

void	execute(char *argv, char **envp)
{
	char	**cmd;
	char	*path;

	cmd = ft_split(argv, ' ');
	path = find_path(cmd[0], envp);
	if (!path)
	{
		free_array(cmd);
		put_error("Error the path not exist\n");
	}
	if (execve(path, cmd, envp) == -1)
	{
		free((path));
		free_array(cmd);
		put_error("Error in execve");
	}
}

// void	execute(char **cmd, char **envp)
// {
// 	char	*path;

// 	path = find_path(cmd[0], envp);
// 	if (!path)
// 	{
// 		free_array(cmd);
// 		put_error("Error the path not exist\n");
// 	}
// 	if (execve(path, cmd, envp) == -1)
// 		put_error("Error in execve\n");
// }

// int main(int argc, char *argv[], char **envp)
// {
// 	char *path;
// 	(void) argc;
// 	(void) argv;
// 	path = find_path("ls", envp);
// 	printf("%s", path);
// 	free(path);
// 	return (0);
// }