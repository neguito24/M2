/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   process.c                                          :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: fdaher <fdaher@student.42.fr>              +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2024/09/10 16:12:30 by fdaher            #+#    #+#             */
/*   Updated: 2024/09/11 17:42:35 by fdaher           ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "pipex.h"

void	process1(int fd[2], char **argv, char **envp)
{
	int		fd_input;

	fd_input = open(argv[1], O_RDONLY);
	if (fd_input == -1)
		put_error ("Failed open file infile\n");
	close (fd[0]);
	if (dup2(fd_input, 0) == -1)
		put_error("Error in dup2_child_input\n");
	if (dup2(fd[1], 1) == -1)
		put_error("Error in dup2_child_pipewrite\n");
	close (fd[1]);
	close (fd_input);
	execute(argv[2], envp);
}

void	process2(int fd[2], char **argv, char **envp)
{
	int		fd_output;

	fd_output = open(argv[4], O_WRONLY | O_CREAT | O_TRUNC, 0644);
	if (fd_output == -1)
		put_error("Failed open file outfile\n");
	close (fd[1]);
	if (dup2 (fd[0], 0) == -1)
		put_error("Error in dup2_parents_piperead\n");
	if (dup2(fd_output, 1) == -1)
		put_error("Error in dup2_child_output\n");
	close (fd[0]);
	close (fd_output);
	execute(argv[3], envp);
}
