/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_print_unsigned.c                                :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: anrivera <anrivera@student.42.fr>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2024/07/02 11:48:56 by anrivera          #+#    #+#             */
/*   Updated: 2024/07/02 12:05:12 by anrivera         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "ft_printf.h"

static void	ft_toprint(unsigned int nb)
{
	if (nb > 9)
	{
		ft_toprint(nb / 10);
	}
	ft_putchar_fd((nb % 10) + '0', 1);
}

int	ft_print_unsigned(unsigned int nb)
{
	unsigned int	i;

	ft_toprint(nb);
	i = 1;
	while (nb > 9)
	{
		nb = nb / 10;
		i++;
	}
	return (i);
}
