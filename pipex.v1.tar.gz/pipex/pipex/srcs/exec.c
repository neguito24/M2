/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   exec.c                                             :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: anrivera <anrivera@student.42.fr>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2025/02/02 01:49:21 by anrivera          #+#    #+#             */
/*   Updated: 2025/02/03 03:10:24 by anrivera         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "../includes/pipex.h"

void	exec(char *argv, char **envp)
{
	char	**command;
	char	*path;

	command = NULL;
	path = NULL;
	command = ft_split(argv, ' ');
	path = find_path(command[0], envp);
	if (!path)
	{
		free_double_array(command);
		free(path);
		error();
	}
	if (execve(path, command, envp) == -1)
		error();
}
