/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_print_format.c                                  :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: anrivera <anrivera@student.42.fr>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2024/06/27 11:02:55 by anrivera          #+#    #+#             */
/*   Updated: 2024/07/02 18:44:12 by anrivera         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "ft_printf.h"
/*Prints and handles the following conversions: cspdiuxX%*/
int	ft_print_format(char c, va_list ap)
{
	int	count;

	count = 0;
	if (c == 'c')
		count += ft_print_char(va_arg(ap, int));
	else if (c == 's')
		count += ft_print_string (va_arg(ap, char *));
	else if (c == 'p')
		count += ft_print_pointer(va_arg(ap, unsigned long), 87);
	else if (c == 'd')
		count += ft_print_int(va_arg(ap, int));
	else if (c == 'i')
		count += ft_print_int(va_arg(ap, int));
	else if (c == 'u')
		count += ft_print_unsigned(va_arg(ap, unsigned int));
	else if (c == 'x')
		count += ft_print_hexa(va_arg(ap, unsigned int), 87);
	else if (c == 'X')
		count += ft_print_hexa(va_arg(ap, unsigned int), 55);
	else if (c == '%')
		count += ft_print_special();
	return (count);
}
