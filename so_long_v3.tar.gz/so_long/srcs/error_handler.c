/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   error_handler.c                                    :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: anrivera <anrivera@student.42.fr>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2025/01/28 14:23:31 by anrivera          #+#    #+#             */
/*   Updated: 2025/01/29 22:23:12 by anrivera         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "../includes/so_long.h"

void	error_file_ext(void)
{
	ft_printf("ERROR: \n Expected BER file extension. \n");
	exit(EXIT_FAILURE);
}

void	error_open_file(void)
{
	ft_printf("ERROR: \n Failed to open file. \n");
}
