/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   map_format.c                                       :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: anrivera <anrivera@student.42.fr>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2025/01/28 14:20:28 by anrivera          #+#    #+#             */
/*   Updated: 2025/01/30 00:59:56 by anrivera         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "../includes/so_long.h"

void	check_file_format(t_map *map)
{
	size_t	len;

	len = ft_strlen(map->file);
	if (map->file[len - 1] != 'r' || map->file[len - 2] != 'e'
		|| map->file[len - 3] != 'b' || map->file[len - 4] != '.')
		error_file_ext();
	if (!ft_strnstr(map->file, ".ber", ft_strlen(map->file)))
		error_file_ext();
}

void	get_map_into_array(t_map *map)
{
	int		fd;

	map->y = 0;
	map->line = "";
	map->content = ft_strdup("");
	fd = open(map->file, O_RDONLY);
	if (fd == -1)
		error_open_file();
	while (map->line)
	{
		map->line = get_next_line(fd);
		if (map->line == NULL)
			break ;
		//map->content = ft_strjoin(map->content, map->line); //check for memory leaks
		map->content = safe_strjoin(map->content, map->line);
		free(map->line);
		if (!map->content)
			free_exit_error(map);
		map->y++;
	}
	close (fd);
	map->fild = ft_split(map->content, '\n');
	map->copy = ft_split(map->content, '\n');
	if (!map->fild || !map->copy)
		free_exit_error(map);
	free(map->content);
}

