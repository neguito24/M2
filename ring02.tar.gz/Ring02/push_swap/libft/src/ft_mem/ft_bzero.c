#include "../../inc/libft.h"

void	ft_bzero(void *buff, size_t n)
{
	ft_memset(buff, 0, n);
}
