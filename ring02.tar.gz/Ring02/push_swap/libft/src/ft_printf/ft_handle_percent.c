#include "../../inc/ft_printf.h"

int	ft_handle_percent(void)
{
	ft_putchar('%');
	return (1);
}
