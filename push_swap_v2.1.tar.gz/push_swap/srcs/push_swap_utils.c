/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   push_swap_utils.c                                  :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: anrivera <anrivera@student.42.fr>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2024/07/31 15:16:56 by anrivera          #+#    #+#             */
/*   Updated: 2025/01/06 17:28:30 by anrivera         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "../includes/push_swap.h"

void	ft_error(void)
{
	ft_putendl_fd ("Error", 1);
	exit(EXIT_FAILURE);
}

void	free_mem_arr(char **arr)
{
	size_t	i;

	i = 0;
	while (arr[i])
	{
		free (arr[i]);
		i++;
	}
	free(arr[i]);
	free (arr);
}

int	ft_check_spaces(char c)
{
	if (c == ' ' || c == '\f' || c == '\n'
		|| c == '\r' || c == '\t' || c == '\v')
		return (1);
	else
		return (0);
}

long	ft_atol(const char *nptr)
{
	int		i;
	int		sign;
	long	integer;

	i = 0;
	sign = 1;
	integer = 0;
	while (ft_check_spaces(nptr[i]))
		i++;
	if (nptr[i] == '-')
		sign = sign * -1;
	if (nptr[i] == '-' || nptr[i] == '+')
		i++;
	while (nptr[i] != '\0' )
	{
		if (nptr[i] >= '0' && nptr[i] <= '9')
		{
			integer = integer * 10 ;
			integer = integer + (nptr[i++] - '0');
		}
		else
			return (integer * sign);
	}
	return (integer * sign);
}

int	ft_count_nbr(char **arr)
{
	int	i;

	i = 0;
	while (arr[i])
		i++;
	ft_printf("Valor size: %d", i);
	return (i);
	
}
