/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   inst_swap.c                                        :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: anrivera <anrivera@student.42.fr>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2024/08/20 15:21:25 by anrivera          #+#    #+#             */
/*   Updated: 2025/01/14 13:40:34 by anrivera         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "../includes/push_swap.h"

void	swap_stack(t_stack **stack)
{
	
	
	if (stack == NULL || (*stack) == NULL || (*stack)->next == NULL)
		return ;
	*stack = (*stack)->next;
	(*stack) -> prev -> next = (*stack) -> next;
	(*stack) -> next = (*stack) -> prev;
	(*stack) -> next -> prev = *stack;
	if((*stack) -> next -> next != NULL)
		(*stack) -> next -> next -> prev = (*stack) -> next;
	(*stack) -> prev = NULL; 
	
	
}
void sa(t_stack **a)
{
	swap_stack (a);
	ft_printf("sa\n");
}
void sb(t_stack **b)
{
	swap_stack (b);
	ft_printf("sa\n");
}
