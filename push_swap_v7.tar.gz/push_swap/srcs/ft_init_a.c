/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_init_a.c                                        :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: anrivera <anrivera@student.42.fr>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2025/01/20 12:04:23 by anrivera          #+#    #+#             */
/*   Updated: 2025/01/21 01:28:27 by anrivera         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "../includes/push_swap.h"

void	set_index(t_stack *stack)
{
	int	id;
	int	median;

	id = 0;
	if (!stack)
		return ;
	median = ft_stack_lenght(stack) / 2;
	while (stack)
	{
		stack->index = id;
		if (id <= median)
			stack->above_median = 1;
		else
			stack->above_median = 0;
		stack = stack->next;
		id++;
	}
}

void	set_target_a(t_stack *a, t_stack *b)
{
	t_stack	*current;
	t_stack	*target_node;
	long	best_opt;

	while (a)
	{
		best_opt = LONG_MIN;
		current = b;
		while (current)
		{
			if (current->nbr < a->nbr && current->nbr > best_opt)
			{
				best_opt = current->nbr;
				target_node = current;
			}
			current = current->next;
		}
		if (best_opt == LONG_MIN)
			a->target = ft_find_max(b);
		else
			a->target = target_node;
		a = a->next;
	}
}

void	set_cost_a(t_stack *a, t_stack *b)
{
	int	size_a;
	int	size_b;

	size_a = ft_stack_lenght(a);
	size_b = ft_stack_lenght(b);
	while (a)
	{
		a->cost = a->index;
		if (!(a->above_median))
			a->cost = size_a - (a->index);
		if (a->target->above_median)
			a->cost = a->cost + a->target->index;
		else
			a->cost = a->cost + (size_b - (a->target->index));
		a = a->next;
	}
}

void	set_cheapest(t_stack *stack)
{
	long	cheapest_val;
	t_stack	*cheapest_node;

	if (!stack)
		return ;
	cheapest_val = LONG_MAX;
	while (stack)
	{
		if (stack->cost < cheapest_val)
		{
			cheapest_val = stack->cost;
			cheapest_node = stack;
		}
		stack = stack->next;
	}
	cheapest_node->cheapest = 1;
}

void	init_a(t_stack *a, t_stack *b)
{
	set_index(a);
	set_index(b);
	set_target_a(a, b);
	set_cost_a(a, b);
	set_cheapest(a);
}
