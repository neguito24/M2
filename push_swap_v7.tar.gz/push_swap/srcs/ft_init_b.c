/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_init_b.c                                        :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: anrivera <anrivera@student.42.fr>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2025/01/21 00:20:59 by anrivera          #+#    #+#             */
/*   Updated: 2025/01/21 01:36:16 by anrivera         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "../includes/push_swap.h"

void	set_target_b(t_stack *a, t_stack *b)
{
	t_stack	*current;
	t_stack	*target_node;
	long	best_index;

	while (b)
	{
		best_index = LONG_MAX;
		current = a;
		while (current)
		{
			if (current->nbr > b->nbr && current->nbr < best_index)
			{
				best_index = current->nbr;
				target_node = current;
			}
			current = current->next;
		}
		if (best_index == LONG_MAX)
			b->target = ft_find_min(a);
		else
			b->target = target_node;
		b = b->next;
	}
}

void	init_b(t_stack *a, t_stack *b)
{
	set_index(a);
	set_index(b);
	set_target_b(a, b);
}

void	min_on_top(t_stack **a)
{
	while ((*a)->nbr != ft_find_min(*a)->nbr)
	{
		if (ft_find_min(*a)->above_median)
			ra(a);
		else
			rra(a);
	}
}
