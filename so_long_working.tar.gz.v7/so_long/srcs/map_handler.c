/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   map_handler.c                                      :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: anrivera <anrivera@student.42.fr>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2025/01/28 12:40:40 by anrivera          #+#    #+#             */
/*   Updated: 2025/02/02 20:30:34 by anrivera         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "../includes/so_long.h"

void	init_map(t_map *map, char **argv)
{
	map->file = argv[1];
	map->moves = 0;
	map->e = 0;
	map->c = 0;
	map->p = 0;
	map->y = 0;
	map->player.y = 0;
	map->player.x = 0;
	map->exit = 0;
	map->fild = NULL;
	map->copy = NULL;
	map->line = "";
	map->content = ft_strdup("");
	mlx_initializer(map);
}

void	mlx_initializer(t_map *map)
{
	map->mlx = NULL;
	map->wnd = NULL;
	map->img.collectible = NULL;
	map->img.empty = NULL;
	map->img.exit = NULL;
	map->img.player = NULL;
	map->img.wall = NULL;
}

void	fill_array(t_map *map, int empty_file, int empty_line)
{
	if (empty_file)
		error_map_format_empty_file(map);
	if (empty_line || !map->content)
		error_map_format_empty_line(map);
	map->fild = ft_split(map->content, '\n');
	map->copy = ft_split(map->content, '\n');
	if (!map->fild || !map->copy)
		free_exit_error(map);
	free(map->content);
}

void	check_map(t_map *map)
{
	check_file_format(map);
	get_map_into_array(map);
	check_map_size(map);
	check_map_limits(map);
	check_map_objects(map);
	check_map_valid_path(map);
	free_map_array(map->copy);
}
