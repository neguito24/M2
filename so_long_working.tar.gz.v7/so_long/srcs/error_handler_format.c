/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   error_handler_format.c                             :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: anrivera <anrivera@student.42.fr>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2025/01/28 14:23:31 by anrivera          #+#    #+#             */
/*   Updated: 2025/02/02 20:35:03 by anrivera         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "../includes/so_long.h"

void	error_map_size(t_map *map)
{
	ft_printf("ERROR: \n Map is not rectangular. \n");
	free_map_array(map->fild);
	free_map_array(map->copy);
	exit(EXIT_FAILURE);
}

void	error_map_limits(t_map *map)
{
	ft_printf("ERROR: \n Map is not limited. \n");
	free_map_array(map->fild);
	free_map_array(map->copy);
	exit(EXIT_FAILURE);
}

void	error_map_objects(t_map *map)
{
	ft_printf("ERROR: \n Map elements are incorrect. \n");
	free_map_array(map->fild);
	free_map_array(map->copy);
	exit(EXIT_FAILURE);
}

void	error_map_invalid_path(t_map *map)
{
	ft_printf("ERROR: \n Map invalid path. \n");
	free_map_array(map->fild);
	free_map_array(map->copy);
	exit(EXIT_FAILURE);
}
