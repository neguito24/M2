/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   map_format.c                                       :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: anrivera <anrivera@student.42.fr>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2025/01/28 14:20:28 by anrivera          #+#    #+#             */
/*   Updated: 2025/02/02 22:18:08 by anrivera         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "../includes/so_long.h"

void	check_file_format(t_map *map)
{
	size_t	len;

	len = ft_strlen(map->file);
	if (map->file[len - 1] != 'r' || map->file[len - 2] != 'e'
		|| map->file[len - 3] != 'b' || map->file[len - 4] != '.')
		error_file_ext(map);
	if (!ft_strnstr(map->file, ".ber", ft_strlen(map->file)))
		error_file_ext(map);
}

void	get_map_into_array(t_map *map)
{
	int		fd;
	int		empty_file;
	int		empty_line;

	empty_file = 1;
	empty_line = 0;
	if (!map->content)
		free_exit_error(map);
	fd = ft_open_file(map);
	while (map->line)
	{
		map->line = get_next_line(fd);
		if (map->line == NULL)
			break ;
		empty_file = 0;
		if (map->line[0] == '\n')
			empty_line = 1;
		map->content = safe_strjoin(map->content, map->line);
		free(map->line);
		if (!map->content)
			free_exit_error(map);
		map->y++;
	}
	close(fd);
	fill_array(map, empty_file, empty_line);
}

void	check_map_size(t_map *map)
{
	int	y;
	int	x;
	int	max_col_size;

	y = 0;
	x = 0;
	max_col_size = ft_strlen(map->fild[y]);
	while (y < map->y)
	{
		x = ft_strlen(map->fild[y]);
		if (max_col_size != x)
			error_map_size(map);
		y++;
	}
	map->x = max_col_size;
}

void	check_map_limits(t_map *map)
{
	int	x;
	int	y;

	x = 0;
	while (map->fild[0][x] != '\0')
	{
		if (map->fild[0][x] != '1' || map->fild[map->y - 1][x] != '1')
			error_map_limits(map);
		x++;
	}
	y = 1;
	while (y < map->y)
	{
		if (map->fild[y][0] != '1' || map->fild[y][map->x - 1] != '1')
			error_map_limits(map);
		y++;
	}
}

void	check_map_objects(t_map *map)
{
	int	y;
	int	x;

	y = 0;
	x = 0;
	while (y < map->y)
	{
		while (x < map->x)
		{
			if (map->fild[y][x] == 'C')
				map->c += 1;
			else if (map->fild[y][x] == 'E')
				map->e += 1;
			else if (map->fild[y][x] == 'P')
				map->p += 1;
			else if (!(map->fild[y][x] == '0' || map->fild[y][x] == '1'))
				error_map_objects(map);
			x++;
		}
		x = 0;
		y++;
	}
	if (map->c == 0 || map->e != 1 || map->p != 1)
		error_map_objects(map);
}
