/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   close_window.c                                     :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: anrivera <anrivera@student.42.fr>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2025/02/02 18:34:38 by anrivera          #+#    #+#             */
/*   Updated: 2025/02/02 21:22:45 by anrivera         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "../includes/so_long.h"

void	free_images(t_map *map)
{
	if (map->img.wall)
		mlx_destroy_image(map->mlx, map->img.wall);
	if (map->img.collectible)
		mlx_destroy_image(map->mlx, map->img.collectible);
	if (map->img.empty)
		mlx_destroy_image(map->mlx, map->img.empty);
	if (map->img.exit)
		mlx_destroy_image(map->mlx, map->img.exit);
	if (map->img.player)
		mlx_destroy_image(map->mlx, map->img.player);
}

int	close_window(t_map *map)
{
	free_images(map);
	mlx_destroy_window(map->mlx, map->wnd);
	if (map->mlx)
	{
		mlx_destroy_display(map->mlx);
		free(map->mlx);
	}
	free_map_array(map->fild);
	exit(EXIT_SUCCESS);
	return (0);
}

void	win(t_map *map)
{
	map->exit = 1;
	map->moves++;
	mlx_clear_window(map->mlx, map->wnd);
	ft_printf("****Congratulations**** YOU WON!!!\n");
	close_window(map);
}
