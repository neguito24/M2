/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   load_file_to_image.c                               :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: anrivera <anrivera@student.42.fr>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2025/02/02 16:27:20 by anrivera          #+#    #+#             */
/*   Updated: 2025/02/02 16:45:53 by anrivera         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "../includes/so_long.h"

void	load_file_to_image(t_map *map)
{
	int	a;

	a = IMG_PXL;
	map->img.empty = mlx_xpm_file_to_image(map->mlx,
			"images/ground.xpm", &a, &a);
	map->img.wall = mlx_xpm_file_to_image(map->mlx,
			"images/wall.xpm", &a, &a);
	map->img.exit = mlx_xpm_file_to_image(map->mlx,
			"images/cave.xpm", &a, &a);
	map->img.collectible = mlx_xpm_file_to_image(map->mlx,
			"images/cactus.xpm", &a, &a);
	map->img.player = mlx_xpm_file_to_image(map->mlx,
			"images/pngegg.xpm", &a, &a);
}
