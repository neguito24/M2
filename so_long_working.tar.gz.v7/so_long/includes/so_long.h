/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   so_long.h                                          :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: anrivera <anrivera@student.42.fr>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2025/01/23 23:57:51 by anrivera          #+#    #+#             */
/*   Updated: 2025/02/02 22:11:55 by anrivera         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#ifndef SO_LONG_H
# define SO_LONG_H
# include "../ft_printf/libft/libft.h"
# include "../ft_printf/libft/get_next_line.h"
# include "../ft_printf/ft_printf.h"
# include "../minilibx-linux/mlx.h"
# include <unistd.h>
# include <stdlib.h>
# include <errno.h>
# include <stdlib.h>
# include <stdio.h>
# include <fcntl.h>

# define IMG_PXL 50
# define UP      65362
# define DOWN    65364
# define LEFT    65361
# define RIGHT   65363
# define W    	 119
# define S    	 115
# define A   	 97
# define D		 100
# define ESC     65307

typedef struct s_player
{
	int	y;
	int	x;

}	t_player;

typedef struct s_img
{
	void	*empty;
	void	*collectible;
	void	*wall;
	void	*exit;
	void	*player;
}	t_img;

typedef struct s_map
{
	int				fd;
	char			*line;
	char			*file;
	char			**fild;
	char			**copy;
	char			*content;
	int				y;
	int				x;
	int				e;
	int				c;
	int				c_check;
	int				e_check;
	int				p;
	int				exit;
	int				moves;
	void			*mlx;
	void			*wnd;
	t_img			img;
	t_player		player;
}	t_map;

void	init_map(t_map *map, char **argv);
void	mlx_initializer(t_map *map);
void	check_map(t_map *map);
void	check_file_format(t_map *map);
void	get_map_into_array(t_map *map);
void	fill_array(t_map *map, int empty_file, int empty_line);
void	check_map_size(t_map *map);
void	check_map_limits(t_map *map);
void	check_map_objects(t_map *map);
void	check_map_valid_path(t_map *map);
char	*safe_strjoin(char *s1, char *s2);
int		ft_open_file(t_map *map);
void	create_map_array(t_map *map);
void	error_file_ext(t_map *map);
void	error_open_file(t_map *map);
void	error_map_format_empty_file(t_map *map);
void	error_map_format_empty_line(t_map *map);
void	error_map_size(t_map *map);
void	error_map_limits(t_map *map);
void	error_map_objects(t_map *map);
void	error_map_invalid_path(t_map *map);
void	free_exit_error(t_map *map);
void	free_map_array( char **fild);
void	free_failed_file_open(t_map *map);
void	set_player_position(t_map *map);
void	walk_routes(int x, int y, t_map *map);
void	load_file_to_image(t_map *map);
void	display_map(t_map *map);
void	prompt_movements(t_map *map);
void	place_item(t_map *map, int x, int y );
int		key_hook(int keycode, t_map *map);
void	update_move(t_map *map, int x, int y, int keypress);
void	move_left(t_map *map);
void	move_right(t_map *map);
void	move_up(t_map *map);
void	move_down(t_map *map);
int		close_window(t_map *map);
void	free_images(t_map *map);
void	win(t_map *map);

#endif