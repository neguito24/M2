/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   get_next_line.c                                    :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: anrivera <anrivera@student.42.fr>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2024/07/03 15:25:23 by anrivera          #+#    #+#             */
/*   Updated: 2025/01/31 14:00:54 by anrivera         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "get_next_line.h"
#include <stdio.h>

void	ft_strcpy(t_list *list, char *str)
{
	int	i;
	int	k;

	if (list == NULL)
		return ;
	k = 0;
	while (list)
	{
		i = 0;
		while (list->str_buf[i])
		{
			if (list->str_buf[i] == '\n')
			{
				str[k++] = '\n';
				str[k] = '\0';
				return ;
			}
			str[k++] = list->str_buf[i++];
		}
		list = list->next;
	}
	str[k] = '\0';
}

int	ft_len_of_line(t_list *list)
{
	int	i;
	int	lenght;

	if (list == NULL)
		return (0);
	lenght = 0;
	while (list)
	{
		i = 0;
		while (list->str_buf[i])
		{
			if (list->str_buf[i] == '\n')
			{
				++lenght;
				return (lenght);
			}
			++i;
			++lenght;
		}
		list = list->next;
	}
	return (lenght);
}

char	*ft_get_line(t_list *list)
{
	int		str_len;
	char	*str;

	if (list == NULL)
		return (NULL);
	str_len = ft_len_of_line(list);
	str = malloc(str_len + 1);
	if (str == NULL)
		return (NULL);
	ft_strcpy(list, str);
	return (str);
}

void	ft_update_list(t_list **list)
{
	t_list	*last_node;
	t_list	*clean_node;
	int		i;
	int		k;
	char	*to_save;

	to_save = malloc(BUFFER_SIZE +1);
	clean_node = malloc(sizeof(t_list));
	if (to_save == NULL || clean_node == NULL)
		return ;
	last_node = ft_find_last_node(*list);
	i = 0;
	k = 0;
	while (last_node->str_buf[i] && last_node->str_buf[i] != '\n')
		++i;
	while (last_node->str_buf[i] && last_node->str_buf[++i])
		to_save[k++] = last_node->str_buf[i];
	to_save[k] = '\0';
	clean_node->str_buf = to_save;
	clean_node->next = NULL;
	ft_free_list(list, clean_node, to_save);
}

char	*get_next_line(int fd)
{
	static t_list	*list = NULL;
	char			*next_line;

	if (fd < 0 || BUFFER_SIZE <= 0)
	{
		list = NULL;
		return (NULL);
	}
	ft_create_list(&list, fd);
	if (list == NULL)
		return (NULL);
	next_line = ft_get_line(list);
	ft_update_list(&list);
	return (next_line);
}

// # include <fcntl.h>
// #include <stdio.h>
// int main (void)
// {
// 	int		fd1;
// 	char	*file1;
// 	char	*line;
// 	// char 	buf[256];
// 	// int 	chars_read;

// 	file1 = "test.txt";
// 	fd1 = open (file1, O_RDONLY);
// 	while ((line = get_next_line(fd1))!=NULL)
// 	{
// 		//line = get_next_line(fd1);
// 		printf("%s", line);
// 		free(line);
// 	}
// 	free(line);
// 	close(fd1);
// }