/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   push_swap.c                                        :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: anrivera <anrivera@student.42.fr>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2024/07/29 12:38:20 by anrivera          #+#    #+#             */
/*   Updated: 2025/01/19 08:59:40 by anrivera         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "../includes/push_swap.h"

int	main(int argc, char *argv[])
{
	t_stack	*a;
	//t_stack	*b;
	char	**arr;

	a = NULL;
	//b = NULL;
	t_stack	*head;

	if (argc == 1)
		exit(EXIT_FAILURE);
	ft_check_format_args(argc, argv);
	if (argc == 2)
	{
		arr = ft_split(argv[1], ' ');
		a = ft_init_stack(arr, 0, ft_count_nbr(arr), 'Y');
	}
	if (argc > 2)
		a = ft_init_stack(argv, 1, argc - 1, 'N');
	
	head = a;
	while (head)
	{
		ft_printf("NUmber from stack o: %d and node address is: %p and prev is %p \n", head -> nbr, (void*) head, (void*) head ->prev);
		head = head -> next;
	}
	if (!ft_stack_sorted(a))
	{
		ft_printf("Borra...No esta ordenado!\n");
		if (ft_stack_lenght(a) == 2)
		{
			sa(&a);
			ft_printf("Borra...len 2!\n");
		}
		else if (ft_stack_lenght(a) == 3)
		{
			ft_sort_three(&a);
			ft_printf("Borra...len 3!\n");
		}
	}
while (a)
	{
		ft_printf("NUmber from stack o: %d and node address is: %p and prev is %p \n", a -> nbr, (void*) a, (void*) a ->prev);
		a = a -> next;
	}
	ft_free_stack(&a);
	ft_free_stack(&head);
	return (0);
}
