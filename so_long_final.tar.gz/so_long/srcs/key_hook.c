/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   key_hook.c                                         :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: anrivera <anrivera@student.42.fr>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2025/02/01 18:21:32 by anrivera          #+#    #+#             */
/*   Updated: 2025/02/02 23:01:53 by anrivera         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "../includes/so_long.h"

void	set_player_position(t_map *map)
{
	map->player.y = 0;
	map->player.x = 0;
	while (map->player.y < map->y)
	{
		while (map->player.x < map->x)
		{
			if (map->field[map->player.y][map->player.x] == 'P')
				break ;
			map->player.x++;
		}
		if (map->field[map->player.y][map->player.x] == 'P')
			break ;
		map->player.x = 0;
		map->player.y++;
	}
}

int	key_hook(int keycode, t_map *map)
{
	set_player_position(map);
	if (keycode == ESC)
		return (close_window(map));
	else if (map->exit == 1)
		return (0);
	else if (keycode == LEFT || keycode == A)
		move_left(map);
	else if (keycode == DOWN || keycode == S)
		move_down(map);
	else if (keycode == RIGHT || keycode == D)
		move_right(map);
	else if (keycode == UP || keycode == W)
		move_up(map);
	return (0);
}
