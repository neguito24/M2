/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   main.c                                             :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: anrivera <anrivera@student.42.fr>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2025/01/23 15:49:55 by anrivera          #+#    #+#             */
/*   Updated: 2025/02/02 23:15:11 by anrivera         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

//Compile : cc  main.c -Lminilibx-linux -lmlx_Linux  -lmlx -lXext -lX11

#include "../includes/so_long.h"

int	main(int argc, char *argv[])
{
	t_map	map;

	if (argc == 2)
	{
		init_map(&map, argv);
		check_map(&map);
		map.mlx = mlx_init();
		if (!map.mlx)
			error_mlx_graphic(&map);
		map.wnd = mlx_new_window(map.mlx, map.x * IMG_PXL,
				map.y * IMG_PXL, "so_long");
		if (!map.wnd)
			error_mlx_graphic(&map);
		load_file_to_image(&map);
		display_map(&map);
		mlx_hook(map.wnd, 17, 0, close_window, &map);
		mlx_key_hook(map.wnd, key_hook, &map);
		mlx_loop(map.mlx);
	}
	else
	{
		ft_printf("Error:\n Usage: ./so_long mapfile \n");
		exit(EXIT_FAILURE);
	}
	return (0);
}
