/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   display_map.c                                      :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: anrivera <anrivera@student.42.fr>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2025/02/01 16:48:43 by anrivera          #+#    #+#             */
/*   Updated: 2025/02/02 23:35:13 by anrivera         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "../includes/so_long.h"

void	place_item(t_map *map, int x, int y )
{
	int	item;

	item = map->field[y / IMG_PXL][x / IMG_PXL];
	if (item == 'C' || item == 'P' || item == 'E' || item == '0')
		mlx_put_image_to_window(map->mlx, map->wnd, map->img.empty, x, y);
	if (item == 'C')
		mlx_put_image_to_window(map->mlx, map->wnd,
			map->img.collectible, x, y);
	else if (item == 'P')
		mlx_put_image_to_window(map->mlx, map->wnd,
			map->img.player, x, y);
	else if (item == 'E')
		mlx_put_image_to_window(map->mlx, map->wnd, map->img.exit, x, y);
	else if (item == '1')
		mlx_put_image_to_window(map->mlx, map->wnd, map->img.wall, x, y);
}

void	display_map(t_map *map)
{
	int	x;
	int	y;

	x = 0;
	y = 0;
	while (y < map->y)
	{
		while (x < map->x)
		{
			place_item(map, x * IMG_PXL, y * IMG_PXL);
			x++;
		}
		x = 0;
		y++;
	}
}

void	prompt_movements(t_map *map)
{
	ft_printf("Moves: %d\n", map->moves);
}
