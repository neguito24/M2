/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   clean_memory.c                                     :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: anrivera <anrivera@student.42.fr>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2025/01/25 19:01:11 by anrivera          #+#    #+#             */
/*   Updated: 2025/02/02 23:35:39 by anrivera         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "../includes/so_long.h"

void	free_exit_error(t_map *map)
{
	if (map->field)
		free_map_array(map->field);
	if (map->copy)
		free_map_array(map->copy);
	if (map->content)
		free(map->content);
	if (map->line)
		free(map->line);
	exit(EXIT_FAILURE);
}

void	free_map_array( char **field)
{
	int	i;

	i = 0;
	while (field[i])
	{
		free(field[i]);
		i++;
	}
	free(field);
}

void	free_failed_file_open(t_map *map)
{
	if (map->content)
		free(map->content);
}
