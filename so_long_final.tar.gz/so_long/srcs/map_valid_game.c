/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   map_valid_game.c                                   :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: anrivera <anrivera@student.42.fr>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2025/01/31 18:11:57 by anrivera          #+#    #+#             */
/*   Updated: 2025/02/02 23:33:34 by anrivera         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "../includes/so_long.h"

void	walk_routes(int x, int y, t_map *map)
{
	char	type;

	type = map->copy[y][x];
	if (type == 'C')
	{
		map->c_check -= 1;
		map->copy[y][x] = '1';
	}
	else if (type == 'E')
	{
		map->e_check -= 1;
		map->copy[y][x] = '1';
	}
	else if (type == '0' || type == 'P')
		map->copy[y][x] = '1';
	else
		return ;
	walk_routes(x + 1, y, map);
	walk_routes(x - 1, y, map);
	walk_routes(x, y + 1, map);
	walk_routes(x, y - 1, map);
}

void	check_map_valid_path(t_map *map)
{
	map->c_check = map->c;
	map->e_check = map->e;
	set_player_position(map);
	walk_routes(map->player.x, map->player.y, map);
	if (map->c_check != 0 || map->e_check >= map->e)
		error_map_invalid_path(map);
}
