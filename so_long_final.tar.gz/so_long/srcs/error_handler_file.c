/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   error_handler_file.c                               :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: anrivera <anrivera@student.42.fr>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2025/02/01 21:02:25 by anrivera          #+#    #+#             */
/*   Updated: 2025/02/02 23:16:56 by anrivera         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "../includes/so_long.h"

void	error_file_ext(t_map *map)
{
	ft_printf("ERROR: \n Expected BER file extension. \n");
	free_failed_file_open(map);
	exit(EXIT_FAILURE);
}

void	error_open_file(t_map *map)
{
	ft_printf("ERROR: \n Failed to open file. \n");
	free_failed_file_open(map);
	exit(EXIT_FAILURE);
}

void	error_map_format_empty_file(t_map *map)
{
	ft_printf("ERROR: \n File empty. \n");
	free_exit_error(map);
	exit(EXIT_FAILURE);
}

void	error_map_format_empty_line(t_map *map)
{
	ft_printf("ERROR: \n Empty line in file. \n");
	free_exit_error(map);
	exit(EXIT_FAILURE);
}

void	error_mlx_graphic(t_map *map)
{
	ft_printf("ERROR: \n Mlx not able to init. \n");
	if (map->mlx)
		free(map->mlx);
	if (map->wnd)
		free(map->wnd);
	free_exit_error(map);
}
