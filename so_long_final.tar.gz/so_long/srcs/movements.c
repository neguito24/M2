/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   movements.c                                        :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: anrivera <anrivera@student.42.fr>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2025/01/31 18:53:39 by anrivera          #+#    #+#             */
/*   Updated: 2025/02/02 23:33:46 by anrivera         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "../includes/so_long.h"

void	update_move(t_map *map, int x, int y, int keypress)
{
	if (keypress == UP || keypress == W)
		y = y - 1;
	else if (keypress == DOWN || keypress == S)
		y = y + 1;
	else if (keypress == LEFT || keypress == A)
		x = x - 1;
	else if (keypress == RIGHT || keypress == D)
		x = x + 1;
	if (map->field[y][x] == 'E' && map->c == 0)
		return (win(map));
	if (map->field[y][x] == 'C')
	{
		map->field[y][x] = '0';
		map->c--;
	}
}

void	move_left(t_map *map)
{
	int	x;
	int	y;

	x = map->player.x;
	y = map->player.y;
	if (x > 0 && map->field[y][x - 1] != '1')
	{
		update_move(map, x, y, LEFT);
		if (map->field[y][x - 1] == 'E' && (map->c != 0 || map->exit == 1))
			return ;
		map->moves++;
		mlx_put_image_to_window(map->mlx, map->wnd, map->img.empty,
			x * IMG_PXL, y * IMG_PXL);
		map->field[y][x] = '0';
		x--;
		prompt_movements(map);
		mlx_put_image_to_window(map->mlx, map->wnd, map->img.empty,
			x * IMG_PXL, y * IMG_PXL);
		mlx_put_image_to_window(map->mlx, map->wnd, map->img.player,
			x * IMG_PXL, y * IMG_PXL);
		map->field[y][x] = 'P';
		map->player.x = x;
	}
}

void	move_right(t_map *map)
{
	int	x;
	int	y;

	x = map->player.x;
	y = map->player.y;
	if (x < map->x && map->field[y][x + 1] != '1')
	{
		update_move(map, x, y, RIGHT);
		if (map->field[y][x + 1] == 'E' && (map->c != 0 || map->exit == 1))
			return ;
		map->moves++;
		mlx_put_image_to_window(map->mlx, map->wnd, map->img.empty,
			x * IMG_PXL, y * IMG_PXL);
		map->field[y][x] = '0';
		x++;
		mlx_put_image_to_window(map->mlx, map->wnd, map->img.empty,
			x * IMG_PXL, y * IMG_PXL);
		mlx_put_image_to_window(map->mlx, map->wnd, map->img.player,
			x * IMG_PXL, y * IMG_PXL);
		map->field[y][x] = 'P';
		prompt_movements(map);
	}
	map->player.x = x;
}

void	move_up(t_map *map)
{
	int	x;
	int	y;

	x = map->player.x;
	y = map->player.y;
	if (y > 0 && map->field[y - 1][x] != '1')
	{
		update_move(map, x, y, UP);
		if (map->field[y - 1][x] == 'E' && (map->c != 0 || map->exit == 1))
			return ;
		map->moves++;
		mlx_put_image_to_window(map->mlx, map->wnd, map->img.empty,
			x * IMG_PXL, y * IMG_PXL);
		map->field[y][x] = '0';
		y--;
		prompt_movements(map);
		mlx_put_image_to_window(map->mlx, map->wnd, map->img.empty,
			x * IMG_PXL, y * IMG_PXL);
		mlx_put_image_to_window(map->mlx, map->wnd, map->img.player,
			x * IMG_PXL, y * IMG_PXL);
		map->field[y][x] = 'P';
		map->player.y = y;
	}
}

void	move_down(t_map *map)
{
	int	x;
	int	y;

	x = map->player.x;
	y = map->player.y;
	if (y < map->y && map->field[y + 1][x] != '1')
	{
		update_move(map, x, y, DOWN);
		if (map->field[y + 1][x] == 'E' && (map->c != 0 || map->exit == 1))
			return ;
		map->moves++;
		mlx_put_image_to_window(map->mlx, map->wnd, map->img.empty,
			x * IMG_PXL, y * IMG_PXL);
		map->field[y][x] = '0';
		y++;
		mlx_put_image_to_window(map->mlx, map->wnd, map->img.empty,
			x * IMG_PXL, y * IMG_PXL);
		mlx_put_image_to_window(map->mlx, map->wnd, map->img.player,
			x * IMG_PXL, y * IMG_PXL);
		map->field[y][x] = 'P';
		prompt_movements(map);
		map->player.y = y;
	}
}
