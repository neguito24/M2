/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   get_next_line.h                                    :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: anrivera <anrivera@student.42.fr>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2024/07/03 15:26:31 by anrivera          #+#    #+#             */
/*   Updated: 2024/07/24 12:41:10 by anrivera         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#ifndef GET_NEXT_LINE_H
# define GET_NEXT_LINE_H

# include <stdlib.h>
# include <unistd.h>

# ifndef BUFFER_SIZE
#  define BUFFER_SIZE 10 
# endif

typedef struct s_list
{
	char			*str_buf;
	struct s_list	*next;
}	t_list;

void	ft_free_list(t_list **list, t_list *clean_node, char *to_save);
void	ft_create_list(t_list **list, int fd);
t_list	*ft_find_last_node(t_list *list);
int		ft_found_new_line(t_list *list);
void	ft_append(t_list **list, char *buf);
void	ft_free_list(t_list **list, t_list *clean_node, char *to_save);
char	*ft_get_line(t_list *list);
void	ft_update_list(t_list **list);
char	*get_next_line(int fd);

#endif