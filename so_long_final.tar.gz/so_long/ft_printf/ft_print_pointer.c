/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_print_pointer.c                                 :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: anrivera <anrivera@student.42.fr>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2024/06/30 09:31:07 by anrivera          #+#    #+#             */
/*   Updated: 2025/01/21 10:26:44 by anrivera         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "ft_printf.h"

static int	ft_count_hexa(unsigned long value)
{
	int				i;
	unsigned long	temp;

	i = 0;
	temp = value;
	if (temp == 0)
		return (1);
	while (temp != 0)
	{
		temp = temp / 16;
		i++;
	}
	return (i);
}

static void	ft_puthexa_fd(unsigned long value, int ascc, int fd)
{
	if (value > 15)
	{
		ft_puthexa_fd(value / 16, ascc, fd);
	}
	if ((value % 16) < 10)
		ft_putchar_fd((value % 16) + 48, fd);
	else
		ft_putchar_fd((value % 16) + ascc, fd);
}

int	ft_print_pointer(unsigned long value, int asc)
{
	int	i;

	i = 0;
	if (value != 0)
	{
		i = i + ft_print_string("0x");
		ft_puthexa_fd(value, asc, 1);
		i = i + ft_count_hexa(value);
		return (i);
	}
	else
	{
		ft_putstr_fd("(nil)", 1);
		return (5);
	}
}
