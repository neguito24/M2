#!/bin/bash

# Define the list of map files
declare -a MAPS=(
    "map_correct_42.ber" "map_correct_6x9.ber" "map_correct_big_20x34.ber"
    "map_correct_big_34x60.ber" "map_correct_small_1c.ber" "map_correct_small.ber"
    "map_fail_0C.ber" "map_fail_0p.ber" "map_fail_2p.ber" "map_fail_3e.ber"
    "map_fail_colectible.ber" "map_fail_empty.ber" "map_fail_empty_line.ber"
    "map_fail_no_exit.ber" "map_fail_no_ext" "map_fail_not_rectangular.ber"
    "map_fail_no_walls.ber" "map_fail_other_char.ber"
)

# Directory where the maps are stored
MAP_DIR="maps/fail"

# Path to the executable
EXEC="./so_long"

# Iterate through each map file
for MAP in "${MAPS[@]}"; do
    echo "========================================="
    echo "Testing: $MAP"
    echo "========================================="
    
    # Run the program normally
    echo "--> Running without Valgrind:"
    $EXEC "$MAP_DIR/$MAP"
    echo "-----------------------------------------"
    
    # Run the program with Valgrind
    echo "--> Running with Valgrind:"
    valgrind --leak-check=full --show-leak-kinds=all $EXEC "$MAP_DIR/$MAP" 2>&1 | \
        grep -E "Core dump|Invalid free\(\) / delete / delete\[\] / realloc\(\)|blocks are still reachable|Invalid read of size 1"
    echo "========================================="
    echo ""
done
